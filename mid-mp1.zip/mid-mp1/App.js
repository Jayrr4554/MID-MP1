import React, { useState } from 'react';
import { View, TextInput, FlatList, Text, StyleSheet, Button } from 'react-native';

const ColorfulList = () => {
  const [inputText, setInputText] = useState('');
  const [listData, setListData] = useState([]);

  const handleInputTextChange = (text) => {
    setInputText(text);
  };

  const handleAddItem = () => {
    if (inputText.trim() !== '') {
      setListData([...listData, { key: inputText }]);
      setInputText('');
    }
  };

  // Function to generate rainbow colors
  const generateRainbowColor = (index) => {
    const frequency = 1;
    const red = Math.sin(frequency * index + 0) * 127 + 128;
    const green = Math.sin(frequency * index + 2) * 127 + 128;
    const blue = Math.sin(frequency * index + 4) * 127 + 128;
    return `rgb(${red}, ${green}, ${blue})`;
  };

  const renderItem = ({ item, index }) => {
    const backgroundColor = generateRainbowColor(index); // Rainbow background colors
    return (
      <View style={[styles.listItem, { backgroundColor }]}>
        <Text>{'\u2022'} {item.key}</Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <Text style={styles.bullet}>{'\u2022'}</Text>
        <TextInput
          style={styles.input}
          onChangeText={handleInputTextChange}
          value={inputText}
          placeholder="Enter a word"
        />
      </View>
      <Button onPress={handleAddItem} title="Add" />
      <FlatList
        data={listData}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  bullet: {
    marginRight: 5,
    fontSize: 20,
    lineHeight: 20,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  listItem: {
    padding: 10,
    marginBottom: 5,
    borderRadius: 5,
  },
});

export default ColorfulList;
